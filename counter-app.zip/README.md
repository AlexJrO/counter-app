# Counter App - React Native

Simple counter app built with React Native and Expo.

## Features

- Increase counter
- Decrease counter
- Reset counter
- Uses useState
- Uses React Native components

## Technologies

- React Native
- Expo
- JavaScript

## Author

Alex
